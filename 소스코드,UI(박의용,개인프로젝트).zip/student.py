from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType
from PyQt5 import uic
import MySQLdb
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtWidgets import QListWidgetItem
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QDate
from PyQt5.QtCore import QTime, Qt
import time
import random



form_class = uic.loadUiType("student.ui")[0]

class Main(QtWidgets.QMainWindow, form_class):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.setupUi(self)
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="school")
        self.curs = self.mydb.cursor()
        self.thread = {}
        # self.clean_prize_name = None
        # self.Thread = None
        self.pick_clear_member_btn.clicked.connect(self.pick_start)
        self.pick_clear_member_stop_btn.clicked.connect(self.pick_stop)
        self.clear_member_btn.clicked.connect(self.movemove)
        self.clean_dateEdit.dateChanged.connect(self.date_clean)
        # self.clean_prize_name.setText(self.clean)

        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.leave_btn.hide()
        self.outing_btn.hide()
        self.comeback_btn.hide()
        self.student_login_btn.clicked.connect(self.login)
        self.attendance_btn.clicked.connect(self.attendance)
        self.leave_btn.clicked.connect(self.leave)
        self.outing_btn.clicked.connect(self.outing)
        self.comeback_btn.clicked.connect(self.comeback)
        self.dateEdit.setDateTime(QtCore.QDateTime.currentDateTime())
        self.date = self.dateEdit.setDateTime(QtCore.QDateTime.currentDateTime())
        self.dateEdit.dateChanged.connect(self.date_attendance)
        self.message_dateEdit.dateChanged.connect(self.date_message)
        self.total_class_lineEdit.setReadOnly(True)
        self.total_class_lineEdit2.setReadOnly(True)
        self.attendance_time_limit = str(self.posibility_attendance_dateTimeEdit.time().toPyTime())
        self.leave_time_avaiable = str(self.posibility_leave_dateTimeEdit.time().toPyTime())
        time = QTime.currentTime()
        self.current_time_string = time.toString()
        self.current_time_data.setText(time.toString())
        self.message_current_time_data.setText(time.toString())
        print(self.attendance_time_limit)
        print(self.leave_time_avaiable)
        self.logout_go.triggered.connect(self.logout)
        self.mainpage_go.triggered.connect(self.mainpage)
        self.attendance_check_btn.clicked.connect(self.attendance_check)
        self.message_btn.clicked.connect(self.message)
        self.send_message_btn.clicked.connect(self.send_message)

        self.calendar_btn.clicked.connect(self.register_calendar)
        self.calendar_add_item_btn.clicked.connect(self.add_new_task)
        self.calendar_add_btn.clicked.connect(self.calendar_add)
        self.calendar_delete_item_btn.clicked.connect(self.delete_task)
        self.calendar_submit_btn.clicked.connect(self.calendar_submit)
        self.calendar_check_btn.clicked.connect(self.calendar_check)
        self.student_schedule_inquiry_btn.clicked.connect(self.schedule_check)
        self.professor_schedule_inquiry_btn.clicked.connect(self.professor_schedule_check)

        self.schedule_check_tableWidget.setColumnWidth(0, 220)
        self.schedule_check_tableWidget.setColumnWidth(1, 500)
        self.schedule_check_tableWidget.setColumnWidth(2, 200)
        self.schedule_check_tableWidget.setColumnWidth(3, 50)
        # if current_time_string < leave_time_avaiable:
        #     print('please')
        #     print(time.toString())
        #     print(attendance_time_limit)
        #     print(leave_time_avaiable)
    # def something(self):
    #     self.parent().callMe()
    # def a(self):
    #     self.Thread = ThreadClass(self.clean_prize_name)

    def movemove(self):
        self.tabWidget.setCurrentIndex(6)

    def clean(self):
        self.curs.execute("SELECT name from school.student ORDER BY RAND() LIMIT 3")
        result = self.curs.fetchall()
        self.clean_prize_name.setText(result)


    def pick_start(self):
        self.thread[1] = ThreadClass(index=1)
        self.thread[1].start()
        self.thread[1].any_signal.connect(self.my_function)
        self.curs.execute("SELECT name from school.student ORDER BY RAND() LIMIT 3")
        result = self.curs.fetchall()
        clean_list = []
        clean_list1 = []
        clean_list2 = []
        clean_list3 = []
        if result:
            for i in result:
                clean_list.append(i[0])
            self.clean_prize_name.setText(str(clean_list))
            clean_list1.append(random.sample(clean_list, 1))
            self.clean_area_label_1.setText(str(clean_list1[0][0]))
            print(clean_list)
            print(clean_list1)
            clean_list.remove(clean_list1[0][0])
            print(clean_list)
            clean_list2.append(random.sample(clean_list, 1))
            self.clean_area_label_2.setText(str(clean_list2[0][0]))
            clean_list.remove(clean_list2[0][0])
            print(clean_list)
            clean_list3.append(random.sample(clean_list, 1))
            self.clean_area_label_3.setText(str(clean_list3[0][0]))
            clean_list.remove(clean_list3[0][0])
            print(clean_list)
            self.curs.execute("SELECT curriculum from school.student where name = '"+self.clean_area_label_1.text()+"'")
            result = self.curs.fetchall()
            if result:
                for i in result:
                    self.clean_curriculum.setText(i[0])
            a = self.clean_dateEdit.text()
            b = self.clean_area_label_1.text()
            c = self.clean_curriculum.text()
            d = self.clean_area_1.text()
            e = self.clean_area_label_2.text()
            f = self.clean_area_label_3.text()
            g = self.clean_area_2.text()
            h = self.clean_area_3.text()
            self.curs.execute(
                "INSERT INTO school.cleanclass(date,name, curriculum, area) SELECT '" + str(a) + "', '" + str(b) + "', '" + str(c) + "', '" + str(d) + "' FROM DUAL WHERE NOT EXISTS(SELECT date,name,curriculum,area  FROM school.cleanclass WHERE date = '" + str(
                    a) + "'  AND name = '" + str(b) + "' AND curriculum = '"+str(c)+"' AND area = '"+str(d)+"' ) ")
            self.curs.execute(
                "INSERT INTO school.cleanclass(date,name, curriculum, area) SELECT '" + str(a) + "', '" + str(
                    e) + "', '" + str(c) + "', '" + str(
                    g) + "' FROM DUAL WHERE NOT EXISTS(SELECT date,name,curriculum,area  FROM school.cleanclass WHERE date = '" + str(
                    a) + "'  AND name = '" + str(e) + "' AND curriculum = '" + str(c) + "' AND area = '" + str(
                    g) + "' ) ")
            self.curs.execute(
                "INSERT INTO school.cleanclass(date,name, curriculum, area) SELECT '" + str(a) + "', '" + str(
                    f) + "', '" + str(c) + "', '" + str(
                    h) + "' FROM DUAL WHERE NOT EXISTS(SELECT date,name,curriculum,area  FROM school.cleanclass WHERE date = '" + str(
                    a) + "'  AND name = '" + str(f) + "' AND curriculum = '" + str(c) + "' AND area = '" + str(
                    h) + "' ) ")
            self.mydb.commit()
            # clean_list1.append(a)
            # clean_list.remove(a)
            # b = random.sample(clean_list,1)
            # clean_list2.append(b)
            # clean_list.remove(b)
            # c = random.sample(clean_list,1)
            # clean_list3.append(c)
            # clean_list.remove(a)
            # self.clean_area_label_1.setText(str(a))
            # self.clean_area_label_2.setText(str(b))
            # self.clean_area_label_3.setText(str(c))
            self.pick_clear_member_btn.setEnabled(False)

    def pick_stop(self):
        self.thread[1].stop()
        self.pick_clear_member_btn.setEnabled(True)

    def my_function(self,counter):

        cnt = counter
        index = self.sender().index
        if index ==1:
            self.progressBar.setValue(cnt)

    def register_calendar(self):
        self.tabWidget.setCurrentIndex(4)
        a = self.student_name_label.text()
        b = self.student_curriculum_label.text()
        c = self.student_number_label.text()
        self.calendar_student_name_label.setText(a)
        self.calendar_student_curriculum_label.setText(b)
        self.calendar_student_number_label.setText(c)
        self.calendarWidget.selectionChanged.connect(self.calendarDateChanged)
        self.calendarDateChanged()

    def calendarDateChanged(self):
        print("date was changed")
        dateSelected = self.calendarWidget.selectedDate().toPyDate()
        print("Date selected:", dateSelected)
        self.calendar_management(dateSelected)

    def calendar_management(self, date):
        self.calendar_listWidget.clear()
        self.curs.execute("SELECT name, task, completed FROM school.calendar WHERE name= '"+self.calendar_student_name_label.text()+"' AND date = '" + str(date) + "'")
        self.curs.fetchall()

        for j in self.curs:
            list = QListWidgetItem(str(j[1]))
            list.setFlags(list.flags() | QtCore.Qt.ItemIsUserCheckable)
            if j[2] == "YES":
                list.setCheckState(QtCore.Qt.Checked)
            elif j[2] == "NO":
                list.setCheckState(QtCore.Qt.Unchecked)
            self.calendar_listWidget.addItem(list)

    def calendar_add(self):
        name = self.calendar_student_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.calendar_submit()
            else:
                query = "UPDATE school.calendar SET completed = 'NO' WHERE name = '"+str(name)+"' AND task = '"+str(task)+"' AND date = '"+str(date)+"'"
            self.curs.execute(query)
        self.mydb.commit()
        messageBox = QMessageBox()
        messageBox.setText("일정이 추가 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def add_new_task(self):
        name = self.calendar_student_name_label.text()
        newTask = self.calendar_add_lineEdit.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        query = "INSERT INTO school.calendar(name, task, date) VALUES ('" + str(name) + "','" + str(newTask) + "', '" + str(date) + "')"

        self.curs.execute(query)
        self.mydb.commit()

        messageBox = QMessageBox()
        messageBox.setText("항목이 추가 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def professor_schedule_check(self):
        self.schedule_check_tableWidget.setRowCount(0)
        self.curs.execute(
            "SELECT * FROM school.calendar WHERE name = '" + self.professor_name_schedule_comboBox.currentText() + "' AND completed = 'YES' ORDER BY date ")
        result = self.curs.fetchall()
        Row = 0
        self.schedule_check_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.schedule_check_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.schedule_check_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.schedule_check_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[2])))
                self.schedule_check_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[3])))
                Row += 1
        else:
            pass

    def schedule_check(self):
        self.schedule_check_tableWidget.setRowCount(0)
        self.curs.execute(
            "SELECT * FROM school.calendar WHERE name = '" + self.calendar_student_name_check_label.text() + "' ORDER BY date " )
        result = self.curs.fetchall()
        Row = 0
        self.schedule_check_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.schedule_check_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.schedule_check_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.schedule_check_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[2])))
                self.schedule_check_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[3])))
                Row += 1
        else:
            pass
    def calendar_check(self):
        self.tabWidget.setCurrentIndex(5)
        a = self.student_name_label.text()
        b = self.student_curriculum_label.text()
        c = self.student_number_label.text()
        self.calendar_student_name_check_label.setText(a)
        self.calendar_student_curriculum_check_label.setText(b)
        self.calendar_student_number_check_label.setText(c)

    def calendar_submit(self):
        name = self.calendar_student_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.curs.execute("UPDATE school.calendar SET completed = 'YES' WHERE name = '" + str(
                    name) + "' AND task = '" + str(task) + "' AND date = '" + str(date) + "'")
                self.mydb.commit()
            else:
                pass
        messageBox = QMessageBox()
        messageBox.setText("일정이 제출 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def delete_task(self):
        name = self.calendar_student_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.curs.execute("DELETE from school.calendar WHERE name = '" + str(
                    name) + "' AND task = '" + str(task) + "' AND date = '" + str(date) + "'")
                self.mydb.commit()
            else:
                pass
        messageBox = QMessageBox()
        messageBox.setText("항목이 삭제 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def mainpage(self):
        self.tabWidget.setCurrentIndex(1)


    def message(self):
        self.tabWidget.setCurrentIndex(3)
        a = self.student_name_label.text()
        b = self.student_curriculum_label.text()
        c = self.student_number_label.text()
        self.message_student_name_label.setText(a)
        self.message_student_curriculum_label.setText(b)
        self.message_student_number_label.setText(c)

    def send_message(self):
        if self.message_box.text():
            reply = QMessageBox.question(self, 'alam', '메세지 전송을 하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                curriculum_data = self.message_student_curriculum_label.text()
                registration_number_data = self.message_student_number_label.text()
                sender_name_data = self.message_student_name_label.text()
                message_data = self.message_box.text()
                receive_name_data = self.professor_name_comboBox.currentText()
                receive_name_belong_data = self.professor_curriculum_combobox.currentText()
                message_date_data = self.message_dateEdit.text()
                message_time_data = self.message_current_time_data.text()
                self.curs.execute(
                    "insert into school.message (curriculum,registration_number,sender_name,message,receive_name,receive_name_belong,date,sender_time)values('" + str(
                        curriculum_data) + "','" + str(int(registration_number_data)) + "', '" + str(sender_name_data) + "', '" + str(
                        message_data) + "', '" + str(receive_name_data) + "', '" + str(receive_name_belong_data) + "', '"+str(message_date_data)+"', '"+str(message_time_data)+"')")
                self.mydb.commit()
                msg = QMessageBox()
                msg.setWindowTitle("광주인력개발원")
                msg.setText("메세지가 전송되었습니다.")
                msg.setIcon(QMessageBox.Information)
                msg.exec_()
            else:
                QMessageBox.information(self, "alam", "메세지 전송을 취소하였습니다.")
        elif self.message_box.text() == '':
            QMessageBox.information(self, "alam", "메세지가 작성되지 않았습니다.")


    def logout(self):
        reply = QMessageBox.question(self, '메세지', '로그아웃 하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "Logout", "로그아웃되었습니다.")
            self.student_name_label.clear()
            self.student_number_label.clear()
            self.student_curriculum_label.clear()
            self.tabWidget.setCurrentIndex(0)
        else:
            pass



    def date_attendance(self):
        self.dateEdit.setDateTime(QtCore.QDateTime.currentDateTime())

    def date_message(self):
        self.message_dateEdit.setDateTime(QtCore.QDateTime.currentDateTime())
        # print("Date changed")
        # dateSelected = str(self.dateEdit.date().toPyDate())
        # print("Date selected:", dateSelected)

    def date_clean(self):
        print("Date changed")
        dateSelected = str(self.dateEdit.date().toPyDate())
        print("Date selected:", dateSelected)

    def login(self):
        id = self.student_id.text()
        pw = self.student_password.text()
        self.curs.execute(
            "SELECT * from school.student WHERE name = '"+str(id)+"' and registration_number = '"+pw+"'"
        )
        result = self.curs.fetchone()
        self.student_id.setText("")
        self.student_password.setText("")
        if result:
            QMessageBox.information(self,"Login","로그인에 성공하였습니다.")
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
            self.student_name_label.setText(id)
            self.curs.execute("SELECT curriculum, registration_number FROM school.student WHERE name = '"+self.student_name_label.text()+"'")
            result = self.curs.fetchall()
            if result:
                for i in result:
                    self.student_curriculum_label.setText(str(i[0]))
                    self.student_number_label.setText(str(int((i[1]))))
                    curriculum = self.student_curriculum_label.text()
                    number = self.student_number_label.text()
                    self.curs.execute("INSERT INTO school.attendance(name,curriculum, registration_number, date) SELECT '"+str(id) +"', '" + str(curriculum) + "', '" + str(int(number)) + "', '" + self.dateEdit.text() + "' FROM DUAL WHERE NOT EXISTS(SELECT name,registration_number  FROM school.attendance WHERE name = '"+str(id)+"'  AND registration_number = '"+str(int(number))+"' ) ")
                    self.mydb.commit()
                    print('test')
                    return curriculum, number
        else:
            QMessageBox.information(self,"Login","유효하지 않은 ID 혹은 비밀번호 입니다.")

        return id


    def attendance(self):
        if self.student_attendance_label.text() == '':
            reply = QMessageBox.question(self,'메세지','입실하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                QMessageBox.information(self,'student','입실하셨습니다.')
                time = QTime.currentTime()
                self.student_attendance_label.setText(time.toString())
                self.leave_btn.show()
                self.outing_btn.show()
                if self.current_time_string > self.attendance_time_limit:
                    QMessageBox.information(self, 'student', '9시 20분이 넘어 지각입니다.')
                    self.curs.execute("UPDATE school.attendance SET entrance_time ='"+self.student_attendance_label.text()+"', tardy_number = 1 WHERE name = '"+str(self.student_name_label.text())+"'")
                    self.mydb.commit()
                if self.current_time_string > self.leave_time_avaiable:
                    QMessageBox.information(self, 'student', '퇴실 시간이 넘어 결석입니다.')
                    self.curs.execute(
                        "UPDATE school.attendance SET absent_number = 1 WHERE name = '" + str(self.student_name_label.text()) + "'")
                    self.mydb.commit()
                    # self.curs.execute("INSERT INTO school.attendance(")
            else:
                QMessageBox.information(self, 'student', '입실허용 시간은 9시 20분입니다.')
        else:
            QMessageBox.information(self, 'student', '이미 입실하였습니다.')

    def leave(self):
        if self.student_attendance_label.text() and self.student_leave_label.text() == '':

            if self.current_time_string < self.leave_time_avaiable:
                reply = QMessageBox.question(self, '메세지', '조퇴하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

                if reply == QMessageBox.Yes:
                    QMessageBox.information(self,'student', '조퇴하였습니다.')
                    time = QTime.currentTime()
                    self.student_leave_label.setText(time.toString())
                    self.outing_btn.hide()
                    self.comeback_btn.hide()
                    self.curs.execute(
                        "UPDATE school.attendance SET leave_time ='" + self.student_leave_label.text() + "', leave_early_number = 1 WHERE name = '" + str(self.student_name_label.text()) + "'")
                    self.mydb.commit()
                else:
                    QMessageBox.information(self, 'student', '수업을 계속 진행해주세요.')

            else:
                reply = QMessageBox.question(self, '메세지', '퇴실하시겠습니까?', QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.Yes:
                    QMessageBox.information(self,'student', '퇴실하였습니다.')
                    time = QTime.currentTime()
                    self.student_leave_label.setText(time.toString())
                    self.outing_btn.hide()
                    self.comeback_btn.hide()
                    self.curs.execute(
                        "UPDATE school.attendance SET leave_time ='" + self.student_leave_label.text() + "', attendance_number = 1 WHERE name = '" + str(self.student_name_label.text()) + "'")
                    self.mydb.commit()
                else:
                    QMessageBox.information(self, 'student', '퇴실 시간이 넘어 오늘 꼭 퇴실을 하셔야 합니다.')
        else:
            QMessageBox.information(self, 'student', '이미 퇴실 하였습니다.')

    def outing(self):
        if self.student_attendance_label.text() and self.student_outing_label.text() == '':
            reply = QMessageBox.question(self, '메세지', '외출하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                QMessageBox.information(self,'student','외출하였습니다.')
                time = QTime.currentTime()
                self.student_outing_label.setText(time.toString())
                self.comeback_btn.show()
                self.curs.execute(
                    "UPDATE school.attendance SET outing_time ='" + self.student_outing_label.text() + "' WHERE name = '" + str(self.student_name_label.text()) + "'")
                self.mydb.commit()

            else:
                QMessageBox.information(self, 'student', '외출허용시간은 정규 수업시간 내입니다.')
        else:
            QMessageBox.information(self, 'student', '이미 외출 하였습니다.')
    #
    def comeback(self):
        if self.student_outing_label.text() and self.student_comeback_label.text() == '':
            reply = QMessageBox.question(self, '메세지', '복귀하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                QMessageBox.information(self,'student','외출 후 복귀 하셨습니다.')
                time = QTime.currentTime()
                self.student_comeback_label.setText(time.toString())
                self.curs.execute(
                    "UPDATE school.attendance SET comeback_time ='" + self.student_comeback_label.text() + "', outing_number = 1 WHERE name = '" + str(
                        self.student_name_label.text()) + "'")
                self.mydb.commit()
            else:
                QMessageBox.information(self, 'student', '외출시간이 기록되어야 복귀가 가능합니다.')
        else:
            QMessageBox.information(self, 'student', '이미 복귀하였습니다.')

    def attendance_check(self):
        self.tabWidget.setCurrentIndex(2)
        a = self.student_name_label.text()
        b = self.student_curriculum_label.text()
        c = self.student_number_label.text()
        self.check_student_curriculum_label.setText(a)
        self.check_student_number_label.setText(b)
        self.check_student_name_label.setText(c)

        self.curs.execute("SELECT * FROM school.attendance WHERE name = '"+str(a)+"'")
        result = self.curs.fetchall()
        if result:
            for i in result:
                print('hi')
                self.attendance_number_label.setText(str(i[8]))
                self.tardy_number_label.setText(str(i[9]))
                self.leave_early_number_label.setText(str(i[10]))
                self.outing_number_label.setText(str(i[11]))
                self.absent_number_label.setText(str(i[12]))
                if self.attendance_number_label.text() == 'None':
                    self.attendance_number_label.setText('0')
                    self.curriculum_progress.setText('0')
                else:
                    pass
                    # self.curriculum_progress.setText("%.2f%%" % (self.attendance_number_label.text() / self.total_class_lineEdit2.text() * 100))
                if self.absent_number_label.text() == 'None':
                    self.absent_number_label.setText('0')

class ThreadClass(QtCore.QThread, QMainWindow):

    any_signal = QtCore.pyqtSignal(int)
    def __init__(self,index=0):
        super(ThreadClass, self).__init__()
        self.index = index
        self.is_running = True
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="school")
        self.curs = self.mydb.cursor()
        # self.widget = Main(parent=self)

    def run(self):
        print('starting thread...', self.index)
        cnt = 0
        while (True):
            cnt += 1
            # if cnt==99:
            #     # self.curs.execute("SELECT name from school.student ORDER BY RAND() LIMIT 3")
            #     # result = self.curs.fetchall()
            #     # self.clean_prize_name.setText(result)
            #     Main.clean(self)

            time.sleep(0.01)
            self.any_signal.emit(cnt)
    def stop(self):
        self.is_running = False
        print('Stopping thread...',self.index)
        self.terminate()


def main():
    app = QtWidgets.QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()