from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType
from PyQt5 import uic
import MySQLdb
from PyQt5 import QtCore
from PyQt5.QtWidgets import QListWidgetItem


form_class = uic.loadUiType("school.ui")[0]

class Main(QMainWindow, form_class):
    def __init__(self):
        QMainWindow.__init__(self)
        self.setupUi(self)
        # 데이터 베이스 연결, 여기서 con은 디비에 연결 하려는 가지고 있는 변수이다.
        # 데이터를 수집하기 위해 커서 객체를 생성 해야 한다.
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="school")
        self.curs = self.mydb.cursor()
        # self.mydb.autocommit(True)
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.professor_login_btn.clicked.connect(self.login)
        self.student_information_save_btn.clicked.connect(self.save_student_details)

        self.logout_go.triggered.connect(self.logout)
        self.checkstudentattendance.triggered.connect(self.check_student_attendance)

        self.ad_student.triggered.connect(self.add_student)
        self.findstudent.triggered.connect(self.find_student)
        self.messagego.triggered.connect(self.message_c)
        self.find_curriculum_combobox.currentIndexChanged.connect(self.fill_student_table)

        self.calendar.triggered.connect(self.calendar_go)
        self.check_schedule_professor_student.triggered.connect(self.check_schedule)

        self.schedule_curriculum_combobox.currentIndexChanged.connect(self.fill_student_registration_number)
        self.schedule_registration_number_combobox.currentIndexChanged.connect(self.fill_student_name)
        self.student_schedule_check_btn.clicked.connect(self.fill_student_schedule_table)
        self.professor_schedule_check_btn.clicked.connect(self.professor_schedule_check)

        self.attendance_curriculum_combobox.currentIndexChanged.connect(self.fill_attendance_table)
        # self.number_attendance_comboBox.currentIndexChanged.connect(self.fill_attendance_name)
        # self.attendance_dateEdit.dateChanged.connect(self.attendance_date)
        # self.attendance_check_btn.clicked.connect(self.attendance_check_data)

        # self.schedule_check_tableWidget.cellClicked.connect()

        self.calendar_add_btn.clicked.connect(self.calendar_add)
        self.calendar_submit_btn.clicked.connect(self.calendar_submit)
        self.calendar_add_item_btn.clicked.connect(self.add_new_task)
        self.calendar_delete_item_btn.clicked.connect(self.delete_task)
        self.message_lookup_btn.clicked.connect(self.messagecheck)


        self.message_tableWidget.setColumnWidth(0, 200)
        self.message_tableWidget.setColumnWidth(1, 50)
        self.message_tableWidget.setColumnWidth(2, 50)
        self.message_tableWidget.setColumnWidth(3, 627)
        self.message_tableWidget.setColumnWidth(4, 50)
        self.message_tableWidget.setColumnWidth(5, 200)
        self.message_tableWidget.setColumnWidth(6, 200)
        self.message_tableWidget.setColumnWidth(7, 200)

        self.schedule_check_tableWidget.setColumnWidth(0,100)
        self.schedule_check_tableWidget.setColumnWidth(1,530)
        self.schedule_check_tableWidget.setColumnWidth(2,200)
        self.schedule_check_tableWidget.setColumnWidth(3,70)
        self.schedule_check_tableWidget.setColumnWidth(4,100)
        self.schedule_check_tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.message_tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.schedule_check_tableWidget.doubleClicked.connect(self.schedule_cellclicked)

        self.attendance_date_tableWidget.setColumnWidth(1, 250)
        self.attendance_time_tableWidget.setColumnWidth(1, 250)

    def schedule_cellclicked(self):
        a = self.schedule_check_tableWidget.currentRow()
        b = self.schedule_check_tableWidget.currentColumn()
        c = self.schedule_check_tableWidget.item(a,b).text()
        print(b, c)
        d = self.schedule_check_tableWidget.columnCount()
        f = self.schedule_check_tableWidget.horizontalHeaderItem(b).text()
        print(f)
        list = []
        for i in range(d):
            list.append(self.schedule_check_tableWidget.item(a,i).text())

        if c == 'NO':
            reply = QMessageBox.question(self, '메세지', '승인하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.curs.execute("UPDATE school.calendar SET completed = 'YES' WHERE name ='"+ list[0] +"'and task ='"+list[1]+"' and date ='"+list[2]+"'")
                self.mydb.commit()
            else:
                pass
        elif c == 'YES':
            reply = QMessageBox.question(self, '메세지', '반려하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.curs.execute("UPDATE school.calendar SET completed = 'NO' WHERE name ='"+ list[0] +"'and task ='"+list[1]+"' and date ='"+list[2]+"'")
                self.mydb.commit()
            else:
                pass
        #     for i in range(a.columnCount()):
        #         print(self.schedule_check_tableWidget.item(a.currentRow(),a.currentColumn()).text())


    def check_student_attendance(self):
        self.tabWidget.setCurrentIndex(4)
        # self.curs.execute("SELECT DISTINCT curriculum from school.attendance")
        # result = self.curs.fetchall()
        # if result:
        #     for i in result:
        #         self.attendance_curriculum_combobox.addItem(str(i[0]))
        # self.curs.close()

    def check_schedule(self):
        self.tabWidget.setCurrentIndex(6)
        # self.curs.execute("SELECT registration_number, name FROM school.student WHERE curriculum ='"+self.schedule_curriculum_combobox.currentText()+"' ")
        # result = self.curs.fetchall()
        # if result:
        #     for i in result:
        #         self.schedule_registration_number_combobox
    def fill_student_registration_number(self):
        self.curs.execute("SELECT registration_number from school.student where curriculum = '"+self.schedule_curriculum_combobox.currentText()+"' ORDER BY registration_number")
        result = self.curs.fetchall()
        if result:
            for i in result:
                self.schedule_registration_number_combobox.addItem(str(int(i[0])))

    def fill_student_name(self):
        self.curs.execute("SELECT name from school.student where registration_number = '"+self.schedule_registration_number_combobox.currentText()+"'")
        result = self.curs.fetchall()
        if result:
            for i in result:
                self.schedule_student_name.setText(str(i[0]))



    #




    # def attendance_check_data(self):
    #     a = self.attendance_name.text()
    #     b = self.attendance_dateEdit.text()
    #     c = self.number_attendance_comboBox.currentText()
    #     self.curs.execute("SELECT * FROM school.attendance WHERE name = '"+a+"' and date = '"+b+"' and registration_number ='"+c+"'")
    #     result = self.curs.fetchall()
    #     if result:
    #         for i in result:
    #             self.student_entrance_time.setText(str(i[4]))
    #             self.student_leave_time.setText(str(i[5]))
    #             self.student_outing_time.setText(str(i[6]))
    #             self.student_comeback_time.setText(str(i[7]))
    #             self.student_attendance_date.setText(str(int(i[8])))
    #             self.student_tardy_date.setText(str(int(i[9])))
    #             self.student_early_leave_date.setText(str(int(i[10])))
    #             self.student_outing_date.setText(str(int(i[11])))
    #             self.student_absent_date.setText(str(int(i[12])))
    #             if self.student_attendance_date.text() == 'None':
    #                 self.student_attendance_date.setText('0')
    #                 self.student_progress_persent.setText('0')
    #             else:
    #                 pass
    #                 # self.curriculum_progress.setText("%.2f%%" % (self.attendance_number_label.text() / self.total_class_lineEdit2.text() * 100))
    #             if self.student_absent_date.text() == 'None':
    #                 self.student_absent_date.setText('0')


    # def pushbutton(self, i):
    #     self.btn1 = QPushButton("승인")
    #     # self.btn1.clicked(True)
    #     if self.btn1.clicked:
    #         print(i)
            # button = self.sender()
            # print(button)
            # item = self.schedule_check_tableWidget.indexAt(button.pos())
            # print(item)
            # return self.btn1




    def fill_student_schedule_table(self):
        self.schedule_check_tableWidget.setRowCount(0)
        self.curs.execute(
            "SELECT * FROM school.calendar WHERE name = '" + self.schedule_student_name.text() + "' ORDER BY date ")
        result = self.curs.fetchall()
        Row = 0
        self.schedule_check_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.schedule_check_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.schedule_check_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.schedule_check_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[2])))
                self.schedule_check_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[3])))
                # self.schedule_check_tableWidget.setCellWidget(Row, 4, self.pushbutton(i))
                Row += 1
        else:
            pass
            # self.btn1.clicked.connect(self.test)

    def professor_schedule_check(self):
        self.schedule_check_tableWidget.setRowCount(0)
        self.curs.execute(
            "SELECT * FROM school.calendar WHERE name = '" + self.professor_schedule_name_comboBox.currentText() + "' ORDER BY date ")
        result = self.curs.fetchall()
        Row = 0
        self.schedule_check_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.schedule_check_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.schedule_check_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.schedule_check_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[2])))
                self.schedule_check_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[3])))
                Row += 1
        else:
            pass



    def logout(self):
        reply = QMessageBox.question(self, '메세지', '로그아웃 하시겠습니까?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "Logout", "로그아웃되었습니다.")
            self.message_professor_name_label.clear()
            self.schedule_professor_name_label.clear()
            self.professor_main_name.clear()
            self.tabWidget.setCurrentIndex(0)
        else:
            pass

    def message_c(self):
        self.tabWidget.setCurrentIndex(7)

    def messagecheck(self):
        check_professor = self.message_professor_name_label.text()
        reply = QMessageBox.question(self, '메세지', '메세지 확인을 하시겠습니까?', QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.curs.execute("SELECT * FROM school.message where receive_name ='" + str(check_professor) + "'")
            result3 = self.curs.fetchall()
            row = 0
            self.message_tableWidget.setRowCount(len(result3))
            if result3:
                for i in result3:
                    self.message_tableWidget.setItem(row, 0, QTableWidgetItem(str(i[1])))
                    self.message_tableWidget.setItem(row, 1, QTableWidgetItem(str(int(i[2]))))
                    self.message_tableWidget.setItem(row, 2, QTableWidgetItem(str(i[3])))
                    self.message_tableWidget.setItem(row, 3, QTableWidgetItem(str(i[4])))
                    self.message_tableWidget.setItem(row, 4, QTableWidgetItem(str(i[5])))
                    self.message_tableWidget.setItem(row, 5, QTableWidgetItem(str(i[6])))
                    self.message_tableWidget.setItem(row, 6, QTableWidgetItem(str(i[7])))
                    self.message_tableWidget.setItem(row, 7, QTableWidgetItem(str(i[8])))
                    row += 1
            else:
                pass

        else:
            pass



    def login(self):
        pi = self.professor_id.text()
        pw = self.professor_password.text()

        if(pi=="이상복" and pw =="admin") or (pi=="류홍걸" and pw =="admin") or (pi=="조동현" and pw =="admin"):
            msg = QMessageBox()
            msg.setWindowTitle("광주인력개발원")
            msg.setText("로그인되었습니다. 환영합니다.")
            msg.setIcon(QMessageBox.Information)
            msg.exec_()
            self.professor_main_name.setText(pi)
            self.message_professor_name_label.setText(pi)
            self.schedule_professor_name_label.setText(pi)
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
            self.curs.execute("SELECT DISTINCT receive_name from school.message where receive_name ='"+str(pi)+"'")
            result1 = self.curs.fetchall()
            self.curs.execute("SELECT COUNT(receive_name) from school.message where receive_name ='"+str(pi)+"'")
            result2 = self.curs.fetchall()

            if result1:
                if result2:
                    for i in result1:
                        for j in result2:
                            QMessageBox.information(self, 'student', f'{i[0]}교수님에게 {j[0]}건의 메세지가 도착했습니다.')
                            reply = QMessageBox.question(self, '메세지', '메세지 확인을 하시겠습니까?', QMessageBox.Yes | QMessageBox.No,
                                                         QMessageBox.No)
                            if reply == QMessageBox.Yes:
                                self.tabWidget.setCurrentIndex(7)
                                self.messagecheck()

                            else:
                                pass

        else:
            msg = QMessageBox()
            msg.setWindowTitle("광주인력개발원")
            msg.setText("회원정보가 일치하지 않습니다.")
            msg.setIcon(QMessageBox.Critical)
            msg.exec_()

    def add_student(self):
        self.tabWidget.setCurrentIndex(2)

    def find_student(self):
        self.tabWidget.setCurrentIndex(3)

    def fill_student_table(self):
        self.curs.execute("SELECT * FROM school.student WHERE curriculum = '"+self.find_curriculum_combobox.currentText()+"'")
        result = self.curs.fetchall()
        Row = 0
        self.student_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.student_tableWidget.setItem(Row, 0, QTableWidgetItem(str(int(i[2]))))
                self.student_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[3])))
                self.student_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[4])))
                self.student_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[5])))
                self.student_tableWidget.setItem(Row, 4, QTableWidgetItem(str(int(i[6]))))
                self.student_tableWidget.setItem(Row, 5, QTableWidgetItem(str(i[7])))
                self.student_tableWidget.setItem(Row, 6, QTableWidgetItem(str(i[8])))
                self.student_tableWidget.setItem(Row, 7, QTableWidgetItem(str(i[9])))
                Row += 1
        else:
            pass

    def fill_attendance_table(self):
        self.curs.execute("SELECT * FROM school.attendance WHERE curriculum = '"+self.attendance_curriculum_combobox.currentText()+"' ORDER BY registration_number, date")
        result = self.curs.fetchall()
        Row = 0
        self.attendance_time_tableWidget.setRowCount(len(result))
        self.attendance_date_tableWidget.setRowCount(len(result))
        if result:
            for i in result:
                self.attendance_time_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.attendance_time_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.attendance_time_tableWidget.setItem(Row, 2, QTableWidgetItem(str(int(i[2]))))
                self.attendance_time_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[3])))
                self.attendance_time_tableWidget.setItem(Row, 4, QTableWidgetItem(str(i[4])))
                self.attendance_time_tableWidget.setItem(Row, 5, QTableWidgetItem(str(i[5])))
                self.attendance_time_tableWidget.setItem(Row, 6, QTableWidgetItem(str(i[6])))
                self.attendance_time_tableWidget.setItem(Row, 7, QTableWidgetItem(str(i[7])))

                self.attendance_date_tableWidget.setItem(Row, 0, QTableWidgetItem(str(i[0])))
                self.attendance_date_tableWidget.setItem(Row, 1, QTableWidgetItem(str(i[1])))
                self.attendance_date_tableWidget.setItem(Row, 2, QTableWidgetItem(str(i[2])))
                self.attendance_date_tableWidget.setItem(Row, 3, QTableWidgetItem(str(i[8])))
                self.attendance_date_tableWidget.setItem(Row, 4, QTableWidgetItem(str(i[9])))
                self.attendance_date_tableWidget.setItem(Row, 5, QTableWidgetItem(str(i[10])))
                self.attendance_date_tableWidget.setItem(Row, 6, QTableWidgetItem(str(i[11])))
                self.attendance_date_tableWidget.setItem(Row, 7, QTableWidgetItem(str(i[12])))
                Row += 1
            # for i in range(self.attendance_time_tableWidget.columnCount()):
            #     if self.attendance_time_tableWidget.item(self.attendance_time_tableWidget.currentRow(), i).text():
            #         self.attendance_time_tableWidget.item(self.attendance_time_tableWidget.currentRow(), i).setText('0')

        else:
            pass

    def calendar_go(self):
        self.tabWidget.setCurrentIndex(5)
        self.calendarWidget.selectionChanged.connect(self.calendarDateChanged)
        self.calendarDateChanged()

    def calendarDateChanged(self):
        print("date was changed")
        dateSelected = self.calendarWidget.selectedDate().toPyDate()
        print("Date selected:", dateSelected)
        self.calendar_management(dateSelected)

    def calendar_management(self, date):
        self.calendar_listWidget.clear()
        self.curs.execute("SELECT name, task, completed FROM school.calendar WHERE date = '"+str(date)+"' AND name = '"+self.schedule_professor_name_label.text()+"'")
        self.curs.fetchall()

        for j in self.curs:
            list = QListWidgetItem(str(j[1]))
            list.setFlags(list.flags() | QtCore.Qt.ItemIsUserCheckable)
            if j[2] == "YES":
                list.setCheckState(QtCore.Qt.Checked)
            elif j[2] == "NO":
                list.setCheckState(QtCore.Qt.Unchecked)
            self.calendar_listWidget.addItem(list)

    def calendar_add(self):
        name = self.schedule_professor_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.calendar_submit()
            else:
                query = "UPDATE school.calendar SET completed = 'NO' WHERE name = '"+str(name)+"' AND task = '"+str(task)+"' AND date = '"+str(date)+"'"
            self.curs.execute(query)
        self.mydb.commit()
        messageBox = QMessageBox()
        messageBox.setText("일정이 추가 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def calendar_submit(self):
        name = self.schedule_professor_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.curs.execute("UPDATE school.calendar SET completed = 'YES' WHERE name = '" + str(
                    name) + "' AND task = '" + str(task) + "' AND date = '" + str(date) + "'")
                self.mydb.commit()
            else:
                pass
        messageBox = QMessageBox()
        messageBox.setText("일정이 제출 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()
    #
    def add_new_task(self):
        name = self.schedule_professor_name_label.text()
        newTask = self.calendar_add_lineEdit.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        query = "INSERT INTO school.calendar(name, task, date) SELECT '"+str(name)+"','"+str(newTask)+"', '"+str(date)+"' FROM DUAL WHERE NOT EXISTS(SELECT task, date FROM school.calendar WHERE task ='"+str(newTask)+"' AND date ='"+str(date)+"')"

        self.curs.execute(query)
        self.mydb.commit()

        messageBox = QMessageBox()
        messageBox.setText("항목이 추가 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def delete_task(self):
        name = self.calendar_student_name_label.text()
        date = self.calendarWidget.selectedDate().toPyDate()
        for i in range(self.calendar_listWidget.count()):
            list = self.calendar_listWidget.item(i)
            task = list.text()
            if list.checkState() == QtCore.Qt.Checked:
                self.curs.execute("DELETE from school.calendar WHERE name = '" + str(
                    name) + "' AND task = '" + str(task) + "' AND date = '" + str(date) + "'")
                self.mydb.commit()
            else:
                pass
        messageBox = QMessageBox()
        messageBox.setText("항목이 삭제 되었습니다.")
        messageBox.setStandardButtons(QMessageBox.Ok)
        messageBox.exec()

    def save_student_details(self):
        curriculum = self.curriculum_combobox.currentText()
        registration_number = self.registration_number.text()
        name = self.student_name.text()
        gender = self.student_gender_combobox.currentText()
        birth = self.student_birth.text()
        age = self.student_age.text()
        address = self.student_address.text()
        phone = self.student_phone.text()
        email = self.student_email.text()

        self.curs.execute(
            "insert into school.student (curriculum,registration_number,name,gender,birth,age,address,phone,email)values('"+str(curriculum)+"','"+str(registration_number)+"', '"+str(name)+"', '"+str(gender)+"', '"+str(birth)+"', '"+str(int(age))+"', '"+str(address)+"', '"+str(phone)+"', '"+str(email)+"' )")
        self.mydb.commit()
        msg = QMessageBox()
        msg.setWindowTitle("광주인력개발원")
        msg.setText("학생정보가 정상적으로 등록되었습니다.")
        msg.setIcon(QMessageBox.Information)
        msg.exec_()
        # self.curs.execute("select * from school.student")
        # result = self.curs.fetchall()
        # if result:
        #     for i in result:




def main():
    app = QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()